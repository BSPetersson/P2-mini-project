#ifndef LED_LIGHT_H
#define LED_LIGHT_H


class LED_Light
{
public:
    LED_Light();
};

#endif // LED_LIGHT_H