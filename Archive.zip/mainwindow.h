#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <readwrite.h>
#include <QTimer>
#include "story.h"
#include <QQueue>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void addPoint(double x, double y);
    void plot();
    void clearData();

public slots:
    void update();


private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
    QSerialPort *arduino;
    Story comm;
    QTimer *updateTimer;
    QVector<double> velVec, timeVec;
};

#endif // MAINWINDOW_H
