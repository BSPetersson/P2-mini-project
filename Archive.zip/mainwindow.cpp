#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QDebug>
#include <QtWidgets>
#include "readwrite.h"
#include "QTimer"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->plot->addGraph();
    ui->plot->graph(0)->setScatterStyle(QCPScatterStyle::ssCircle);
    ui->plot->graph(0)->setLineStyle(QCPGraph::lsNone);

    updateTimer = new QTimer(this);
    connect(updateTimer, SIGNAL(timeout()), this, SLOT(update()));
    updateTimer->start(300);

    comm.setup();
    qDebug() << "wait for 5 seconds before booting to wait for Arduino";
    QThread::sleep(5);


    if(comm.initializer == true){
        comm.read();
        qDebug() << "read loaded";
        comm.sendMessage(QString("v100"));
        comm.sendMessage(QString("s%1").arg(comm.place));
        comm.actions(comm.place);
    }
}

MainWindow::~MainWindow() {
    if(arduino->isOpen()){
            arduino->close();
        }
    delete ui;
}

void MainWindow::addPoint(int x, int y)
{
    timeVec.append(x);
    velVec.append(y);
}

void MainWindow::plot()
{
    ui->plot->graph(0)->setData(timeVec, velVec);
    ui->plot->replot();
    ui->plot->update();
}

void MainWindow::clearData()
{

}

void MainWindow::update() {
    comm.next();
}

void MainWindow::on_pushButton_clicked()
{
    addPoint(ui->valx->value(),ui->valy->value());
    plot();
}
