#include "led_light.h"

LED_Light::LED_Light()
{
    private:
    public:
      LEDLight();
      void setColor(int, int, int);
      void dead();
      void river();
      void forest();
      void bear();
      void bigOlSnakes();
      void waterfall();
      void win();
}
